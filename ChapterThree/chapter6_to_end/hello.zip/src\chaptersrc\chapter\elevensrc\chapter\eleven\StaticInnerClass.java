package chapter.eleven;

public class StaticInnerClass {
	
	int x = 100;
	static class Inner{
		void doitInner() {
			
		}
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			System.out.println("a");
		}
	}
	
	

}
