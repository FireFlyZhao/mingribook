package chapter.eleven;

public final class FinalClass {
	
	int a = 3;
	
	void doit() {
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalClass f = new FinalClass();
		f.a++;
		System.out.println(f.a);
	}

}
