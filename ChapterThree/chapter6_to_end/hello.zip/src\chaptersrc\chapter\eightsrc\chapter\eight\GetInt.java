package chapter.eight;

public class GetInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer inte = new Integer(456);
		int myint = inte.intValue(); 
		System.out.println(myint);
	}

}
