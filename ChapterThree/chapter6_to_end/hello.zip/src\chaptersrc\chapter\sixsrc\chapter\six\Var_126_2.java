package chapter.six;

import java.util.Arrays;

public class Var_126_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = new int[] {10, 2, 3, 4, 5, 6, 7, 8, 9 };
		Arrays.sort(arr);
		System.out.println(arr[0]);
	}

}
