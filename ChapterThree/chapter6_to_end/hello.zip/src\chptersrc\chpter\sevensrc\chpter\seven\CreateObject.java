package chpter.seven;

public class CreateObject {

	public CreateObject() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("��������");
	}
	public static void main(String[] args) {
		new CreateObject();
	}
}
