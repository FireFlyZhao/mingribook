package chapter.thirteen;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class CheckBoxTest extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel panel1 = new JPanel();
	private JPanel panel2 = new JPanel();
	private JTextArea jt = new JTextArea(3,10);
	private JCheckBox jc1 = new JCheckBox("1");
	private JCheckBox jc2 = new JCheckBox("2");
	private JCheckBox jc3 = new JCheckBox("3");
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new CheckBoxTest();
	}
	public CheckBoxTest() {
		Container c=getContentPane();
		setSize(200,160);
		setVisible(true);
		setTitle("��ѡ���ʹ��");
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		c.setLayout(new BorderLayout());
		
		c.add(panel1, BorderLayout.NORTH);
		final JScrollPane scrollPane = new JScrollPane(jt);
		panel1.add(scrollPane);
		
		c.add(panel2, BorderLayout.SOUTH);
		panel2.add(jc1);
		jc1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(jc1.isSelected())
					jt.append("��ѡ��1��ѡ��\n");
			}
		});
		
		panel2.add(jc2);
		jc2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				if(jc2.isSelected())
				jt.append("��ѡ��2��ѡ��\n");
			}
		});
		
		panel2.add(jc3);
		jc3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				if(jc3.isSelected())
				jt.append("��ѡ��3��ѡ��\n");
			}
		});
	}
}
