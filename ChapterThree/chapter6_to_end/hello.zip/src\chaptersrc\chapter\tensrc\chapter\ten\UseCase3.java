package chapter.ten;

public abstract class UseCase3 {
	abstract void doit();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		new UseCase3();
	}

}
