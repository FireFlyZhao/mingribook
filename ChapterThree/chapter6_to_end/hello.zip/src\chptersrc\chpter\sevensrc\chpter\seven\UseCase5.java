package chpter.seven;

public class UseCase5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object o = new UseCase1();
		UseCase1 u =   (UseCase1) o;
		
	}

}
