package chpter.seven;

public class UseCase3 extends UseCase1 {
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}
