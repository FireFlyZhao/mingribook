package chapter.nine;

public class IntFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Math.ceil(5.2));
		System.out.println(Math.floor(2.5));
		System.out.println(Math.rint(2.7));
		System.out.println(Math.rint(2.5));
		System.out.println(Math.round(3.4f));
		System.out.println(Math.round(2.5));
		Float myfloat = new Float(3.4f);
		System.out.println(myfloat.intValue());
	}

}
