package chapter.eleven;

import static java.lang.Math.max;
import static java.lang.System.out;

public class ImportTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		out.println("1��4�Ľϴ�ֵΪ��" + max(1, 4));
	}

}
