package chapter.nine;

public class AnyFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Math.max(4, 8));
		System.out.println(Math.min(4.4, 4));
		System.out.println(Math.abs(-7));
	}

}
