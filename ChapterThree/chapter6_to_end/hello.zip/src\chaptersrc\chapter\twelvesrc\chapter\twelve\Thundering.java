package chapter.twelve;

public class Thundering {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "lili";
		System.out.println(str + "������:");
		int age = Integer.parseInt(str);
		System.out.println(age);
	}

}
