package chapter.twelve;

public class Baulk {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int result = 3 / 0;
		System.out.println(result);
	}	

}
